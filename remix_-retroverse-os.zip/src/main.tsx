import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { sentinel } from './services/sentinel';

// Start Sentinel Auditing (Only in Dev)
if (import.meta.env.DEV) {
  console.log('📦 [Main] Starting Sentinel...');
  sentinel.start();
}

// Mock WakeLock to prevent "Access to Screen Wake Lock features is disallowed by permissions policy"
if (typeof navigator !== 'undefined' && 'wakeLock' in navigator) {
  try {
    const originalRequest = navigator.wakeLock.request.bind(navigator.wakeLock);
    navigator.wakeLock.request = async (type: 'screen') => {
      try {
        return await originalRequest(type);
      } catch (err) {
        console.warn('⚠️ [Main] WakeLock request failed (Permission Policy):', err);
        // Return a mock sentinel to prevent crashes in libraries that expect it
        return {
          released: false,
          type: 'screen',
          release: async () => {},
          addEventListener: () => {},
          removeEventListener: () => {},
          onrelease: null,
        } as any;
      }
    };
  } catch (e) {
    console.error('❌ [Main] Failed to mock WakeLock:', e);
  }
}

// Global error handler for boot issues
window.onerror = (message, source, lineno, colno, error) => {
  console.error('🔥 [Main] Global Error Caught:', { message, source, lineno, colno, error });
  // If we're in a black screen state, try to show something
  const root = document.getElementById('root');
  if (root && root.innerHTML === '') {
    root.innerHTML = `
      <div style="background: #0a0a0a; color: #ff4444; padding: 20px; font-family: monospace; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
        <h1 style="margin-bottom: 20px; font-size: 24px; letter-spacing: 2px;">SYSTEM BOOT FAILURE</h1>
        <p style="color: #666; max-width: 600px; font-size: 14px;">${message}</p>
        <button onclick="window.location.reload()" style="margin-top: 30px; background: #222; color: #0f0; border: 1px solid #0f0; padding: 10px 20px; font-family: monospace; cursor: pointer; text-transform: uppercase;">REBOOT SYSTEM</button>
      </div>
    `;
  }
};

// Register Service Worker for Offline Support and SAB enablement
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(registration => {
      console.log('✅ [Main] ServiceWorker registered:', registration.scope);
      
      // If we're not cross-origin isolated, we need to reload the page
      // so the service worker can intercept the main document request
      // and add the COOP/COEP headers.
      if (window.crossOriginIsolated === false) {
        // Wait for the service worker to be active and controlling the page
        if (registration.active && !navigator.serviceWorker.controller) {
          console.log('🔄 [Main] Reloading to enable SharedArrayBuffer (COOP/COEP)...');
          window.location.reload();
        }
        
        // Also listen for the controllerchange event
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          console.log('🔄 [Main] Controller changed, reloading...');
          window.location.reload();
        });
      }
    }).catch(err => {
      console.error('❌ [Main] ServiceWorker registration failed:', err);
    });
  });
}

import { ErrorBoundary } from './components/ErrorBoundary.tsx';

const rootElement = document.getElementById('root');
if (rootElement) {
  console.log('📦 [Main] Mounting React root...');
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>,
  );
  console.log('✅ [Main] React root mounted');
} else {
  console.error('❌ [Main] Root element not found!');
}
