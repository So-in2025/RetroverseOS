import { storage } from './storage';

export interface Transaction {
  id: string;
  amount: number;
  type: 'earn' | 'spend';
  reason: string;
  timestamp: number;
}

class EconomyService {
  private balance: number = 0;
  private xp: number = 0;
  private transactions: Transaction[] = [];
  private listeners: Set<(balance: number, xp: number) => void> = new Set();

  async init() {
    this.balance = await storage.getCredits();
    this.xp = await storage.getXP();
    const savedTransactions = await storage.getSetting('retro_coins_transactions');
    this.transactions = savedTransactions || [];
  }

  getBalance(): number {
    return this.balance;
  }

  getXP(): number {
    return this.xp;
  }

  getTransactions(): Transaction[] {
    return this.transactions;
  }

  async addCoins(amount: number, reason: string) {
    if (amount <= 0) return;
    
    this.balance = await storage.addCredits(amount);
    
    this.addTransaction({
      id: crypto.randomUUID(),
      amount,
      type: 'earn',
      reason,
      timestamp: Date.now()
    });

    await this.saveTransactions();
    this.notifyListeners();

    // Sync to cloud if enabled
    import('./supabase').then(({ supabase }) => {
      if (supabase) {
        supabase.auth.getUser().then(({ data: { user } }) => {
          if (user) {
            import('./profileSyncService').then(({ profileSync }) => {
              profileSync.syncProfile(user.id);
            });
          }
        });
      }
    });

    if (this.balance >= 5000) {
      // We need to import achievements at the top
      import('./achievements').then(({ achievements }) => {
        achievements.unlock('capitalist');
      });
    }
  }

  async addXP(amount: number, reason: string) {
    if (amount <= 0) return;
    
    this.xp = await storage.addXP(amount);
    
    // XP doesn't need transactions for now, but we could add them
    this.notifyListeners();

    // Check for level up or achievements
    if (this.xp >= 10000) {
      import('./achievements').then(({ achievements }) => {
        achievements.unlock('veteran_pilot');
      });
    }
  }

  async spendCoins(amount: number, reason: string): Promise<boolean> {
    if (amount <= 0 || this.balance < amount) return false;

    // storage.addCredits can take negative amounts
    this.balance = await storage.addCredits(-amount);
    
    // Track total spent
    const totalSpent = (await storage.getSetting('total_spent_coins') || 0) + amount;
    await storage.saveSetting('total_spent_coins', totalSpent);

    if (totalSpent >= 10000) {
      import('./achievements').then(({ achievements }) => {
        achievements.unlock('high_roller');
      });
    }

    this.addTransaction({
      id: crypto.randomUUID(),
      amount,
      type: 'spend',
      reason,
      timestamp: Date.now()
    });

    await this.saveTransactions();
    this.notifyListeners();

    // Sync to cloud if enabled
    import('./supabase').then(({ supabase }) => {
      if (supabase) {
        supabase.auth.getUser().then(({ data: { user } }) => {
          if (user) {
            import('./profileSyncService').then(({ profileSync }) => {
              profileSync.syncProfile(user.id);
            });
          }
        });
      }
    });

    return true;
  }

  private addTransaction(transaction: Transaction) {
    this.transactions.unshift(transaction);
    // Keep only last 100 transactions
    if (this.transactions.length > 100) {
      this.transactions = this.transactions.slice(0, 100);
    }
  }

  private async saveTransactions() {
    await storage.saveSetting('retro_coins_transactions', this.transactions);
  }

  subscribe(listener: (balance: number, xp: number) => void) {
    this.listeners.add(listener);
    listener(this.balance, this.xp);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.balance, this.xp));
  }
}

export const economy = new EconomyService();
