import { CoverService } from './coverService';

export interface GameObject {
  game_id: string;
  title: string;
  system: string;
  system_id: string;
  year: number | null;
  publisher: string | null;
  developer: string | null;
  players: number;
  rom_url: string;
  cover_url: string | null;
  artwork_url: string | null;
  video_preview_url?: string | null;
  description?: string | null;
  genre?: string | null;
  rom_size: number;
  emulator_core: string;
  compatibility_status: 'compatible' | 'unstable' | 'broken' | 'untested' | 'verified' | 'unknown';
  checksum: string | null;
  playable?: boolean;
}

export interface ArchiveRawData {
  identifier: string;
  title?: string;
  description?: string;
  creator?: string | string[];
  developer?: string | string[]; // Added to capture if available
  publisher?: string | string[]; // Added to capture if available
  date?: string;
  subject?: string | string[];
  files?: ArchiveFile[];
}

export interface ArchiveFile {
  name: string;
  source: string;
  format: string;
  size: string;
  md5?: string;
  crc32?: string;
}

const SYSTEM_MAPPINGS: Record<string, { system: string; core: string; extensions: string[] }> = {
  'atari_2600': { system: 'Atari 2600', core: 'stella', extensions: ['.bin', '.a26', '.zip'] },
  'nes': { system: 'NES', core: 'fceumm', extensions: ['.nes', '.zip'] },
  'snes': { system: 'SNES', core: 'snes9x', extensions: ['.smc', '.sfc', '.zip'] },
  'sega_genesis': { system: 'Genesis', core: 'genesis_plus_gx', extensions: ['.gen', '.bin', '.md', '.zip'] },
  'gba': { system: 'GBA', core: 'mgba', extensions: ['.gba', '.zip'] },
  'gbc': { system: 'GBC', core: 'gambatte', extensions: ['.gbc', '.zip'] },
  'gb': { system: 'GB', core: 'gambatte', extensions: ['.gb', '.zip'] },
  'psx': { system: 'PS1', core: 'pcsx_rearmed', extensions: ['.bin', '.cue', '.iso', '.chd', '.zip'] },
  'ps2': { system: 'PS2', core: 'play', extensions: ['.iso', '.zip'] },
  'n64': { system: 'N64', core: 'mupen64plus_next', extensions: ['.n64', '.z64', '.zip'] },
  'mastersystem': { system: 'Master System', core: 'genesis_plus_gx', extensions: ['.sms', '.zip'] },
  'gamegear': { system: 'Game Gear', core: 'genesis_plus_gx', extensions: ['.gg', '.zip'] },
  'pcengine': { system: 'PC Engine', core: 'mednafen_pce_fast', extensions: ['.pce', '.zip'] },
  'atari_7800': { system: 'Atari 7800', core: 'prosystem', extensions: ['.a78', '.zip'] },
  'lynx': { system: 'Atari Lynx', core: 'handy', extensions: ['.lnx', '.zip'] },
  'wonderswan': { system: 'WonderSwan', core: 'mednafen_wswan', extensions: ['.ws', '.wsc', '.zip'] },
  'ngp': { system: 'Neo Geo Pocket', core: 'mednafen_ngp', extensions: ['.ngp', '.ngc', '.zip'] },
  'Unknown': { system: 'Unknown', core: 'auto', extensions: [] }
};

// Helper to map Archive.org identifiers/collections to our systems
const COLLECTION_TO_SYSTEM: Record<string, string> = {
  'Atari - 2600': 'atari_2600',
  'Atari - 7800': 'atari_7800',
  'Atari - Lynx': 'lynx',
  'Nintendo - Nintendo Entertainment System': 'nes',
  'Nintendo - Super Nintendo Entertainment System': 'snes',
  'Sega - Mega Drive - Genesis': 'sega_genesis',
  'Nintendo - Game Boy Advance': 'gba',
  'Sony - PlayStation': 'psx',
  'Sony - PlayStation 2': 'ps2',
  'Nintendo - Nintendo 64': 'n64',
  'Sega - Master System - Mark III': 'mastersystem',
  'Sega - Game Gear': 'gamegear',
  'NEC - PC Engine - TurboGrafx 16': 'pcengine',
  'Bandai - WonderSwan': 'wonderswan',
  'SNK - Neo Geo Pocket': 'ngp'
};

/**
 * ELITE TOP 20: The face of Retroverse OS.
 * These identifiers are guaranteed to work and represent the best of each system.
 */
export const ELITE_TOP_20 = [
  'Super Mario World',
  'The Legend of Zelda: A Link to the Past',
  'Mortal Kombat II',
  'Sonic the Hedgehog 2',
  'Pokemon Emerald',
  'Castlevania: Symphony of the Night',
  'Resident Evil 2',
  'Tekken 3',
  'Crash Bandicoot: Warped',
  'Mario Kart 64',
  'GoldenEye 007',
  'Star Fox 64',
  'Donkey Kong Country',
  'Street Fighter II Turbo',
  'Mega Man X',
  'Metroid Fusion',
  'Final Fantasy VII',
  'Gran Turismo 2',
  'Spyro: Year of the Dragon',
  'Tony Hawk\'s Pro Skater 2'
];

export class MetadataNormalizationEngine {
  
  public static async resolveRomUrl(identifier: string, system?: string): Promise<string | null> {
    const maxRetries = 4;
    let attempt = 0;

    while (attempt < maxRetries) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout per attempt

      try {
        const metaTargetUrl = `https://archive.org/metadata/${identifier}`;
        const proxyUrl = `/api/tunnel?url=${encodeURIComponent(metaTargetUrl)}`;
        
        let response;
        try {
          console.log(`[RomResolver] Fetching metadata for ${identifier} (Attempt ${attempt + 1}/${maxRetries})`);
          response = await fetch(proxyUrl, { signal: controller.signal });
        } catch (e: any) {
          console.warn(`[RomResolver] Proxy failed for ${identifier}: ${e.message}`);
          
          // If it's the last attempt, try direct
          if (attempt === maxRetries - 1) {
            console.log(`[RomResolver] Final attempt for ${identifier}, trying direct...`);
            try {
              response = await fetch(metaTargetUrl, { signal: controller.signal });
            } catch (e2: any) {
              console.error(`[RomResolver] Direct fetch also failed for ${identifier}:`, e2.message);
              throw e2;
            }
          } else {
            throw e;
          }
        }
        
        if (response && response.ok) {
          const text = await response.text();
          
          if (!text || text.trim().toLowerCase().startsWith('<!doctype')) {
             throw new Error("Received HTML instead of JSON from Archive.org");
          }

          let metaData;
          try {
            metaData = JSON.parse(text);
          } catch (parseError) {
            console.error(`[RomResolver] Failed to parse JSON for ${identifier}:`, text.substring(0, 100));
            throw new Error("Invalid JSON response from Archive.org");
          }

          if (metaData && metaData.files) {
            let validExtensions: string[] = [];
            if (system === 'nes') validExtensions = ['.nes', '.zip'];
            else if (system === 'snes') validExtensions = ['.sfc', '.smc', '.zip'];
            else if (system === 'sega_genesis') validExtensions = ['.md', '.gen', '.bin', '.zip'];
            else if (system === 'gba') validExtensions = ['.gba', '.zip'];
            else if (system === 'gbc') validExtensions = ['.gbc', '.zip'];
            else if (system === 'gb') validExtensions = ['.gb', '.zip'];
            else if (system === 'n64') validExtensions = ['.n64', '.z64', '.zip'];
            else if (system === 'psx') validExtensions = ['.chd', '.cue', '.bin', '.iso', '.zip'];
            else if (system === 'atari_2600') validExtensions = ['.a26', '.bin', '.zip'];
            else if (system === 'atari_7800') validExtensions = ['.a78', '.bin', '.zip'];
            else if (system === 'lynx') validExtensions = ['.lnx', '.zip'];
            else if (system === 'mastersystem' || system === 'gamegear') validExtensions = ['.sms', '.gg', '.zip'];
            else if (system === 'pcengine') validExtensions = ['.pce', '.zip'];
            else if (system === 'wonderswan') validExtensions = ['.ws', '.wsc', '.zip'];
            else if (system === 'ngp') validExtensions = ['.ngp', '.ngc', '.zip'];

            const romFile = this.findMainRom(metaData.files, validExtensions);
            if (romFile) {
              clearTimeout(timeoutId);
              return `https://archive.org/download/${identifier}/${encodeURIComponent(romFile.name)}`;
            } else {
              console.warn(`[RomResolver] No valid ROM file found in metadata for ${identifier}.`);
              clearTimeout(timeoutId);
              return null; 
            }
          } else {
            console.warn(`[RomResolver] No files found in metadata for ${identifier}`);
            clearTimeout(timeoutId);
            return null;
          }
        } else if (response) {
          console.warn(`[RomResolver] Metadata fetch failed for ${identifier} with status ${response.status}`);
          if (response.status === 404) {
            clearTimeout(timeoutId);
            return null;
          }
          throw new Error(`HTTP ${response.status}`);
        }
      } catch (e: any) {
        attempt++;
        console.error(`[RomResolver] Attempt ${attempt} failed for ${identifier}:`, e.message);
        if (attempt < maxRetries) {
          // Exponential backoff with jitter
          const delay = Math.pow(2, attempt) * 1000 + Math.random() * 1000;
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          break;
        }
      } finally {
        clearTimeout(timeoutId);
      }
    }
    return null;
  }

  public static normalizeFast(doc: any): GameObject | null {
    const identifier = doc.identifier;
    const collection = Array.isArray(doc.collection) ? doc.collection[0] : doc.collection;
    
    let systemKey = '';
    if (collection && COLLECTION_TO_SYSTEM[collection]) {
      systemKey = COLLECTION_TO_SYSTEM[collection];
    } else {
      const subjects = Array.isArray(doc.subject) ? doc.subject : [doc.subject || ''];
      for (const s of subjects) {
        const lowerS = s?.toLowerCase() || '';
        if (lowerS.includes('atari 2600') || lowerS.includes('vcs')) systemKey = 'atari_2600';
        else if (lowerS.includes('atari 7800')) systemKey = 'atari_7800';
        else if (lowerS.includes('atari lynx')) systemKey = 'lynx';
        else if (lowerS.includes('nes') || lowerS.includes('nintendo entertainment system')) systemKey = 'nes';
        else if (lowerS.includes('snes') || lowerS.includes('super nintendo')) systemKey = 'snes';
        else if (lowerS.includes('genesis') || lowerS.includes('mega drive')) systemKey = 'sega_genesis';
        else if (lowerS.includes('gba') || lowerS.includes('game boy advance') || lowerS.includes('gameboy advance')) systemKey = 'gba';
        else if (lowerS.includes('gbc') || lowerS.includes('game boy color') || lowerS.includes('gameboy color')) systemKey = 'gbc';
        else if (lowerS.includes('gb') || lowerS.includes('game boy') || lowerS.includes('gameboy')) systemKey = 'gb';
        else if (lowerS.includes('playstation') && !lowerS.includes('playstation 2') && !lowerS.includes('ps2')) systemKey = 'psx';
        else if (lowerS.includes('playstation 2') || lowerS.includes('ps2')) systemKey = 'ps2';
        else if (lowerS.includes('nintendo 64') || lowerS.includes('n64')) systemKey = 'n64';
        else if (lowerS.includes('master system')) systemKey = 'mastersystem';
        else if (lowerS.includes('game gear')) systemKey = 'gamegear';
        else if (lowerS.includes('pc engine') || lowerS.includes('turbografx')) systemKey = 'pcengine';
        else if (lowerS.includes('wonderswan')) systemKey = 'wonderswan';
        else if (lowerS.includes('neo geo pocket')) systemKey = 'ngp';
        if (systemKey) break;
      }
    }

    if (!systemKey) systemKey = 'Unknown';
    const mapping = SYSTEM_MAPPINGS[systemKey] || SYSTEM_MAPPINGS['Unknown'];

    const cleanTitle = this.cleanTitle(doc.title || identifier);
    
    // Filter out obvious non-games or unplayable items
    const lowerTitle = cleanTitle.toLowerCase();
    const lowerId = identifier.toLowerCase();
    
    // List of known Arcade BIOS/Device files that should never be in the catalog
    const arcadeBiosFiles = [
      'neogeo', 'pgm', 'qsound', 'cpzn1', 'cpzn2', 'cvs', 'decocass', 'konamigx', 
      'megatech', 'megaplay', 'nss', 'playch10', 'skns', 'stvbios', 'taitofx1', 'tps',
      'mame', 'naomi', 'hikaru', 'model3', 'awbios', 'dc_boot', 'dc_flash',
      'atps', 'atps2', 'atps3', 'atps4', 'atps5', 'atps6', 'atps7', 'atps8', 'atps9',
      'atps10', 'atps11', 'atps12', 'atps13', 'atps14', 'atps15', 'atps16', 'atps17',
      'atps18', 'atps19', 'atps20', 'atps21', 'atps22', 'atps23', 'atps24', 'atps25',
      'atps26', 'atps27', 'atps28', 'atps29', 'atps30', 'atps31', 'atps32', 'atps33',
      'atps34', 'atps35', 'atps36', 'atps37', 'atps38', 'atps39', 'atps40', 'atps41',
      'atps42', 'atps43', 'atps44', 'atps45', 'atps46', 'atps47', 'atps48', 'atps49',
      'atps50', 'atps51', 'atps52', 'atps53', 'atps54', 'atps55', 'atps56', 'atps57',
      'atps58', 'atps59', 'atps60', 'atps61', 'atps62', 'atps63', 'atps64', 'atps65',
      'atps66', 'atps67', 'atps68', 'atps69', 'atps70', 'atps71', 'atps72', 'atps73',
      'atps74', 'atps75', 'atps76', 'atps77', 'atps78', 'atps79', 'atps80', 'atps81',
      'atps82', 'atps83', 'atps84', 'atps85', 'atps86', 'atps87', 'atps88', 'atps89',
      'atps90', 'atps91', 'atps92', 'atps93', 'atps94', 'atps95', 'atps96', 'atps97',
      'atps98', 'atps99', 'atps100', 'emus', 'emulators', 'pc-world', 'pc-gamer', 'pc-magazine'
    ];

    const blacklistedKeywords = [
      'bios', 'soundtrack', 'manual', 'not working', 'update', 'magazine', 'guide', 
      'romset', 'rom set', 'rom pack', 'chd pack', 'full set', 'collection', 
      'emulator', 'rollback', 'samples', 'artwork', 'flyers', 'snaps', 'titles', 
      'marquees', 'cabinets', 'cpanel', 'pcb', 'history', 'cheat', 'crosshair',
      'pc world', 'pc gamer', 'pc magazine', 'coverdisc', 'cover disc', 'demo disc',
      'preview disc', 'review disc', 'gog edition', 'steam edition', 'repack',
      'installer', 'setup', 'utility', 'driver', 'software', 'shareware', 'freeware',
      'patch', 'crack', 'trainer', 'portable', 'rip', 'full game', 'disc 1', 'disc 2',
      'disc 3', 'disc 4', 'disc 5', 'cd-rom', 'cdrom', 'dvd-rom', 'dvdrom'
    ];

    if (blacklistedKeywords.some(k => lowerTitle.includes(k)) || 
        arcadeBiosFiles.includes(lowerId) ||
        arcadeBiosFiles.some(b => lowerTitle === b) ||
        lowerTitle.match(/mame\s*0\.\d+/) ||
        lowerTitle.match(/^[0-9]+\s+[0-9a-z\s]+stario$/)) {
      return null;
    }

    const year = this.extractYear(doc.date);
    const publisher = this.extractPublisher(doc.creator);

    // Libretro Art Logic
    const libretroSystemNames: Record<string, string> = {
      'nes': 'Nintendo - Nintendo Entertainment System',
      'snes': 'Nintendo - Super Nintendo Entertainment System',
      'sega_genesis': 'Sega - Mega Drive - Genesis',
      'gba': 'Nintendo - Game Boy Advance',
      'gbc': 'Nintendo - Game Boy Color',
      'gb': 'Nintendo - Game Boy',
      'psx': 'Sony - PlayStation',
      'ps2': 'Sony - PlayStation 2',
      'atari_2600': 'Atari - 2600',
      'atari_7800': 'Atari - 7800',
      'n64': 'Nintendo - Nintendo 64',
      'mastersystem': 'Sega - Master System - Mark III',
      'gamegear': 'Sega - Game Gear',
      'pcengine': 'NEC - PC Engine - TurboGrafx 16',
      'wonderswan': 'Bandai - WonderSwan',
      'ngp': 'SNK - Neo Geo Pocket'
    };

    const libretroSystem = ((mapping as any).system_id ? libretroSystemNames[(mapping as any).system_id] : (libretroSystemNames[systemKey] || mapping.system));
    const sources = CoverService.getCoverSources(doc.title || identifier, systemKey, identifier);
    const coverUrl = sources[0];
    const artworkUrl = sources.find(s => s.includes('Named_Snaps')) || sources[1] || null;

    let genre = null;
    if (doc.subject) {
      genre = Array.isArray(doc.subject) ? doc.subject[0] : doc.subject;
    }

    let description = doc.description || null;
    if (description) {
      description = description.replace(/<[^>]*>?/gm, '').trim();
      if (description.length > 300) description = description.substring(0, 300) + '...';
    }

    return {
      game_id: identifier,
      title: cleanTitle,
      system: mapping.system,
      system_id: systemKey,
      year: year,
      publisher: publisher,
      developer: publisher,
      players: this.estimatePlayers(cleanTitle, description),
      rom_url: `archive:${identifier}`, // Placeholder to be resolved later
      cover_url: coverUrl,
      artwork_url: artworkUrl,
      description: description,
      genre: genre,
      rom_size: 1024 * 1024, // Dummy size to pass filters
      emulator_core: mapping.core,
      compatibility_status: 'untested',
      checksum: null,
      playable: true
    };
  }

  /**
   * Normaliza los metadatos crudos de Archive.org en un GameObject uniforme.
   */
  public static normalize(rawData: ArchiveRawData, collection?: string): GameObject | null {
    // 1. Verificar ROM principal
    const romFile = this.findMainRom(rawData.files || [], []); // Pass empty to find any supported
    if (!romFile) return null; 

    // Attempt to determine system from collection name or subject
    let systemKey = '';
    
    // Try to find a matching system in our mappings based on collection or subject
    if (collection && COLLECTION_TO_SYSTEM[collection]) {
      systemKey = COLLECTION_TO_SYSTEM[collection];
    } else {
      // Fallback: Check subjects/keywords
      const subjects = Array.isArray(rawData.subject) ? rawData.subject : [rawData.subject || ''];
      for (const s of subjects) {
        const lowerS = s?.toLowerCase() || '';
        if (lowerS.includes('atari 2600') || lowerS.includes('vcs')) systemKey = 'atari_2600';
        else if (lowerS.includes('atari 7800')) systemKey = 'atari_7800';
        else if (lowerS.includes('atari lynx')) systemKey = 'lynx';
        else if (lowerS.includes('nes') || lowerS.includes('nintendo entertainment system')) systemKey = 'nes';
        else if (lowerS.includes('snes') || lowerS.includes('super nintendo')) systemKey = 'snes';
        else if (lowerS.includes('genesis') || lowerS.includes('mega drive')) systemKey = 'sega_genesis';
        else if (lowerS.includes('gba') || lowerS.includes('game boy advance') || lowerS.includes('gameboy advance')) systemKey = 'gba';
        else if (lowerS.includes('gbc') || lowerS.includes('game boy color') || lowerS.includes('gameboy color')) systemKey = 'gbc';
        else if (lowerS.includes('gb') || lowerS.includes('game boy') || lowerS.includes('gameboy')) systemKey = 'gb';
        else if (lowerS.includes('playstation') && !lowerS.includes('playstation 2') && !lowerS.includes('ps2')) systemKey = 'psx';
        else if (lowerS.includes('playstation 2') || lowerS.includes('ps2')) systemKey = 'ps2';
        else if (lowerS.includes('nintendo 64') || lowerS.includes('n64')) systemKey = 'n64';
        else if (lowerS.includes('master system')) systemKey = 'mastersystem';
        else if (lowerS.includes('game gear')) systemKey = 'gamegear';
        else if (lowerS.includes('pc engine') || lowerS.includes('turbografx')) systemKey = 'pcengine';
        else if (lowerS.includes('wonderswan')) systemKey = 'wonderswan';
        else if (lowerS.includes('neo geo pocket')) systemKey = 'ngp';
        else if (lowerS.includes('neogeo')) systemKey = 'neogeo';
        else if (lowerS.includes('mame') || lowerS.includes('arcade')) systemKey = 'mame';
        
        if (systemKey) break;
      }
    }

    // MANDATORY: If system still undefined, extract from extension
    if (!systemKey) {
      const ext = romFile.name.split('.').pop()?.toLowerCase();
      if (ext === 'nes') systemKey = 'nes';
      else if (ext === 'sfc' || ext === 'smc') systemKey = 'snes';
      else if (ext === 'gba') systemKey = 'gba';
      else if (ext === 'gbc') systemKey = 'gbc';
      else if (ext === 'gb') systemKey = 'gb';
      else if (ext === 'bin' || ext === 'gen' || ext === 'md') systemKey = 'sega_genesis';
      else if (ext === 'iso' || ext === 'chd' || ext === 'cue') systemKey = 'psx';
      else if (ext === 'a26') systemKey = 'atari_2600';
      else if (ext === 'a78') systemKey = 'atari_7800';
      else if (ext === 'lnx') systemKey = 'lynx';
      else if (ext === 'n64' || ext === 'z64') systemKey = 'n64';
      else systemKey = 'Unknown';
    }

    const mapping = SYSTEM_MAPPINGS[systemKey] || SYSTEM_MAPPINGS['Unknown'];

    // 2. Corregir títulos
    const cleanTitle = this.cleanTitle(rawData.title || rawData.identifier);

    // Filter out obvious non-games or unplayable items
    const lowerTitle = cleanTitle.toLowerCase();
    const lowerId = rawData.identifier.toLowerCase();
    
    const arcadeBiosFiles = [
      'neogeo', 'pgm', 'qsound', 'cpzn1', 'cpzn2', 'cvs', 'decocass', 'konamigx', 
      'megatech', 'megaplay', 'nss', 'playch10', 'skns', 'stvbios', 'taitofx1', 'tps',
      'mame', 'naomi', 'hikaru', 'model3', 'awbios', 'dc_boot', 'dc_flash',
      'atps', 'atps2', 'atps3', 'atps4', 'atps5', 'atps6', 'atps7', 'atps8', 'atps9',
      'atps10', 'atps11', 'atps12', 'atps13', 'atps14', 'atps15', 'atps16', 'atps17',
      'atps18', 'atps19', 'atps20', 'atps21', 'atps22', 'atps23', 'atps24', 'atps25',
      'atps26', 'atps27', 'atps28', 'atps29', 'atps30', 'atps31', 'atps32', 'atps33',
      'atps34', 'atps35', 'atps36', 'atps37', 'atps38', 'atps39', 'atps40', 'atps41',
      'atps42', 'atps43', 'atps44', 'atps45', 'atps46', 'atps47', 'atps48', 'atps49',
      'atps50', 'atps51', 'atps52', 'atps53', 'atps54', 'atps55', 'atps56', 'atps57',
      'atps58', 'atps59', 'atps60', 'atps61', 'atps62', 'atps63', 'atps64', 'atps65',
      'atps66', 'atps67', 'atps68', 'atps69', 'atps70', 'atps71', 'atps72', 'atps73',
      'atps74', 'atps75', 'atps76', 'atps77', 'atps78', 'atps79', 'atps80', 'atps81',
      'atps82', 'atps83', 'atps84', 'atps85', 'atps86', 'atps87', 'atps88', 'atps89',
      'atps90', 'atps91', 'atps92', 'atps93', 'atps94', 'atps95', 'atps96', 'atps97',
      'atps98', 'atps99', 'atps100', 'emus', 'emulators', 'pc-world', 'pc-gamer', 'pc-magazine'
    ];

    const blacklistedKeywords = [
      'bios', 'soundtrack', 'manual', 'not working', 'update', 'magazine', 'guide', 
      'romset', 'rom set', 'rom pack', 'chd pack', 'full set', 'collection', 
      'emulator', 'rollback', 'samples', 'artwork', 'flyers', 'snaps', 'titles', 
      'marquees', 'cabinets', 'cpanel', 'pcb', 'history', 'cheat', 'crosshair',
      'pc world', 'pc gamer', 'pc magazine', 'coverdisc', 'cover disc', 'demo disc',
      'preview disc', 'review disc', 'gog edition', 'steam edition', 'repack',
      'installer', 'setup', 'utility', 'driver', 'software', 'shareware', 'freeware',
      'patch', 'crack', 'trainer', 'portable', 'rip', 'full game', 'disc 1', 'disc 2',
      'disc 3', 'disc 4', 'disc 5', 'cd-rom', 'cdrom', 'dvd-rom', 'dvdrom'
    ];

    if (blacklistedKeywords.some(k => lowerTitle.includes(k)) || 
        arcadeBiosFiles.includes(lowerId) ||
        arcadeBiosFiles.some(b => lowerTitle === b) ||
        lowerTitle.match(/mame\s*0\.\d+/) ||
        lowerTitle.match(/^[0-9]+\s+[0-9a-z\s]+stario$/)) {
      return null;
    }

    // 3. Extraer año
    const year = this.extractYear(rawData.date);

    // 4. Extraer publisher y developer
    const publisher = this.extractPublisher(rawData.publisher || rawData.creator);
    const developer = this.extractPublisher(rawData.developer || rawData.creator);

    // 5. Construir URLs
    const romUrl = `https://archive.org/download/${rawData.identifier}/${encodeURIComponent(romFile.name)}`;
    
    // --- TRIPLE ART CASCADE ENGINE ---
    const sources = CoverService.getCoverSources(rawData.title || rawData.identifier, systemKey, rawData.identifier);
    const coverUrl = sources[0];
    
    let artworkUrl = null;
    const priorityArtwork = rawData.files?.find(f => 
      f.name.toLowerCase().includes('art') || 
      f.name.toLowerCase().includes('background') ||
      f.name.toLowerCase().includes('promo')
    );

    if (priorityArtwork) {
      artworkUrl = `https://archive.org/download/${rawData.identifier}/${encodeURIComponent(priorityArtwork.name)}`;
    } else {
      // Use Libretro Named_Snaps for artwork/background if available in sources
      artworkUrl = sources.find(s => s.includes('Named_Snaps')) || sources[1] || null;
    }
    
    // 6. Buscar video preview o gif
    // Priority: Archive.org mp4 > screenscraper (not implemented yet)
    const videoFile = rawData.files?.find(f => f.name.endsWith('.mp4') || f.name.endsWith('.gif'));
    const videoPreviewUrl = videoFile ? `https://archive.org/download/${rawData.identifier}/${encodeURIComponent(videoFile.name)}` : null;

    // 7. Extraer género
    let genre = null;
    if (rawData.subject) {
      if (Array.isArray(rawData.subject)) {
        genre = rawData.subject[0];
      } else {
        genre = rawData.subject;
      }
    }

    // 8. Limpiar descripción (quitar HTML si lo hay, o limitar tamaño)
    let description = rawData.description || null;
    if (description) {
      // Remover tags HTML básicos
      description = description.replace(/<[^>]*>?/gm, '').trim();
      if (description.length > 300) {
        description = description.substring(0, 300) + '...';
      }
    }

    return {
      game_id: rawData.identifier.replace(/\s+/g, '_'),
      title: cleanTitle,
      system: mapping.system,
      system_id: systemKey,
      year: year,
      publisher: publisher,
      developer: developer,
      players: this.estimatePlayers(cleanTitle, rawData.description),
      rom_url: romUrl,
      cover_url: coverUrl,
      artwork_url: artworkUrl,
      video_preview_url: videoPreviewUrl,
      description: description,
      genre: genre,
      rom_size: parseInt(romFile.size || '0', 10),
      emulator_core: mapping.core,
      compatibility_status: 'untested',
      checksum: romFile.crc32 || romFile.md5 || null,
      playable: true
    };
  }

  /**
   * Encuentra el archivo ROM principal basado en las extensiones soportadas.
   */
  private static findMainRom(files: ArchiveFile[], validExtensions: string[]): ArchiveFile | null {
    const allSupported = ['.nes', '.sfc', '.smc', '.gba', '.gbc', '.gb', '.bin', '.gen', '.md', '.iso', '.chd', '.cue', '.a26', '.a78', '.lnx', '.n64', '.z64', '.zip', '.7z', '.rar'];
    const specificExtensions = validExtensions.length > 0 ? validExtensions : allSupported;
    const fallbackExtensions = ['.zip', '.7z', '.rar'];
    
    // Helper to check if a file name looks like a ROM and not metadata/artwork
    const isLikelyRom = (name: string) => {
      const lower = name.toLowerCase();
      // Exclude common non-ROM files found in archives
      const exclusions = [
        'art', 'cover', 'manual', 'soundtrack', 'video', 'snap', 
        'readme', 'info', 'metadata', 'license', 'install', 'setup',
        '__ia_thumb', 'xml', 'txt', 'pdf', 'jpg', 'png', 'gif', 'mp4',
        'flyer', 'cabinet', 'marquee', 'cpanel', 'pcb', 'history', 'cheat',
        'crosshair', 'sample', 'artwork', 'device', 'bios', 'pc world', 
        'pc gamer', 'pc magazine', 'coverdisc', 'cover disc', 'demo disc',
        'preview disc', 'review disc', 'gog edition', 'steam edition', 'repack',
        'installer', 'setup', 'utility', 'driver', 'software', 'shareware', 'freeware',
        'patch', 'crack', 'trainer', 'portable', 'rip', 'full game'
      ];
      
      if (exclusions.some(exc => lower.includes(exc))) return false;
      
      // Also exclude files that are clearly just extensions of other files
      if (lower.endsWith('.xml') || lower.endsWith('.txt') || lower.endsWith('.pdf')) return false;
      
      return true;
    };

    // 1. Try 'original' files that are likely ROMs with specific extensions
    const originalCandidates = files.filter(f => f.source === 'original');
    
    // PRIORITIZE CHD for PSX/PS2 as it's a single file format
    if (validExtensions.includes('.chd') || validExtensions.includes('.iso')) {
        const chd = originalCandidates.find(f => f.name?.toLowerCase().endsWith('.chd'));
        if (chd) return chd;
    }

    // CRITICAL: Iterate over extensions first to ensure priority (e.g. .nes before .zip)
    for (const ext of specificExtensions) {
      // Skip fallbacks in the first pass if we have specific ones
      if (validExtensions.length > 0 && fallbackExtensions.includes(ext) && ext !== specificExtensions[0]) continue;
      
      for (const file of originalCandidates) {
        if (!file.name) continue;
        const lowerName = file.name.toLowerCase();
        if (lowerName.endsWith(ext) && isLikelyRom(file.name)) {
          return file;
        }
      }
    }

    // 2. Try 'original' files with fallback extensions (.zip) if not found yet
    for (const ext of fallbackExtensions) {
      for (const file of originalCandidates) {
        if (!file.name) continue;
        const lowerName = file.name.toLowerCase();
        if (lowerName.endsWith(ext) && isLikelyRom(file.name)) {
          return file;
        }
      }
    }

    // 3. Try any file that is likely a ROM with specific extensions
    for (const ext of specificExtensions) {
      for (const file of files) {
        if (!file.name) continue;
        const lowerName = file.name.toLowerCase();
        if (lowerName.endsWith(ext) && isLikelyRom(file.name)) {
          return file;
        }
      }
    }

    // 4. Try any file with fallback extensions (.zip)
    for (const ext of fallbackExtensions) {
      for (const file of files) {
        if (!file.name) continue;
        const lowerName = file.name.toLowerCase();
        if (lowerName.endsWith(ext) && isLikelyRom(file.name)) {
          return file;
        }
      }
    }

    // 5. Ultimate Fallback: Try any file that matches any supported extension
    const allExts = [...specificExtensions, ...fallbackExtensions];
    for (const file of originalCandidates) {
      if (!file.name) continue;
      const lowerName = file.name.toLowerCase();
      if (allExts.some(ext => lowerName.endsWith(ext))) {
        return file;
      }
    }
    
    return null;
  }

  /**
   * Limpia el título eliminando tags molestos como (USA), (Rev A), [!], etc.
   * También elimina guiones bajos y extensiones.
   */
  private static cleanTitle(rawTitle: string): string {
    return rawTitle
      .replace(/_/g, ' ') // Replace underscores with spaces
      .replace(/\.[^/.]+$/, '') // Remove extension
      .replace(/\s*[(\[].*?[)\]]/g, '') // Remove content in parentheses or brackets
      .trim();
  }

  /**
   * Extrae el año de publicación de un string de fecha.
   */
  private static extractYear(dateStr?: any): number | null {
    if (!dateStr) return null;
    const str = String(dateStr);
    const match = str.match(/\b(19[7-9]\d|20[0-2]\d)\b/);
    return match ? parseInt(match[1], 10) : null;
  }

  /**
   * Normaliza el campo de creador/publisher.
   */
  private static extractPublisher(creator?: string | string[]): string | null {
    if (!creator) return null;
    if (Array.isArray(creator)) return creator[0];
    return creator;
  }

  /**
   * Estima el número de jugadores basado en el título o descripción (heurística básica).
   */
  private static estimatePlayers(title: string, description?: string): number {
    const textToAnalyze = `${title} ${description || ''}`.toLowerCase();
    if (textToAnalyze.includes('2 player') || textToAnalyze.includes('two player') || textToAnalyze.includes('multiplayer')) {
      return 2;
    }
    if (textToAnalyze.includes('4 player') || textToAnalyze.includes('four player')) {
      return 4;
    }
    return 1; // Por defecto
  }

  /**
   * Elimina duplicados de una lista de GameObjects basándose en el título y sistema.
   * Prioriza las versiones con mejor checksum o tamaño.
   */
  public static deduplicate(games: GameObject[]): GameObject[] {
    const uniqueGames = new Map<string, GameObject>();

    for (const game of games) {
      // Clave única basada en título limpio y sistema
      const key = `${game.title.toLowerCase()}_${game.system}`;
      
      if (!uniqueGames.has(key)) {
        uniqueGames.set(key, game);
      } else {
        // Lógica de resolución de colisiones: preferir la ROM más grande (suele tener menos recortes)
        const existing = uniqueGames.get(key)!;
        if (game.rom_size > existing.rom_size) {
          uniqueGames.set(key, game);
        }
      }
    }

    return Array.from(uniqueGames.values());
  }

  /**
   * Search Archive.org for games matching the query and system.
   * Filters by 'No-Intro' or 'Ghostlight' collections.
   */
  public static async searchArchiveOrg(query: string, system?: string, rows: number = 100, page: number = 1): Promise<GameObject[]> {
    // PROXY ROTATION STRATEGY
    const proxies = [
      { name: 'LocalTunnel', url: '/api/tunnel?url=', timeout: 45000 },
      { name: 'Direct', url: '', timeout: 15000 },
      { name: 'CorsProxy', url: 'https://corsproxy.io/?', timeout: 25000 },
      { name: 'CodeTabs', url: 'https://api.codetabs.com/v1/proxy?quest=', timeout: 25000 },
      { name: 'AllOrigins', url: 'https://api.allorigins.win/raw?url=', timeout: 25000 }
    ];

    // Simplified Query Strategy: "OR" everything to avoid complexity errors
    const systemSubjects: Record<string, string[]> = {
      'arcade': ['mame', 'arcade', 'neogeo'],
      'nes': ['nes', 'nintendo entertainment system'],
      'snes': ['snes', 'super nintendo'],
      'sega': ['sega genesis', 'mega drive', 'master system', 'game gear'],
      'gameboy': ['gb', 'gameboy', 'gbc', 'gameboy color', 'gba', 'gameboy advance'],
      'playstation': ['psx', 'playstation'],
      'ps2': ['ps2', 'playstation 2'],
      'n64': ['n64', 'nintendo 64'],
      'atari': ['atari 2600', 'vcs', 'atari 7800', 'atari lynx'],
      'otras': ['pc engine', 'turbografx', 'wonderswan', 'neo geo pocket']
    };

    const systemCollections: Record<string, string[]> = {
      'arcade': ['softwarelibrary_mame', 'softwarelibrary_neogeo'],
      'nes': ['softwarelibrary_nes', 'no-intro-nes'],
      'snes': ['softwarelibrary_snes', 'no-intro-snes'],
      'sega': ['softwarelibrary_sega_genesis', 'no-intro-genesis', 'softwarelibrary_ms', 'no-intro-ms', 'softwarelibrary_gg', 'no-intro-gg'],
      'gameboy': ['softwarelibrary_gb', 'no-intro-gb', 'softwarelibrary_gbc', 'no-intro-gbc', 'softwarelibrary_gba', 'no-intro-gba'],
      'playstation': ['softwarelibrary_psx', 'redump-sony-playstation'],
      'n64': ['softwarelibrary_n64', 'no-intro-n64'],
      'atari': ['softwarelibrary_atari'],
      'otras': ['softwarelibrary_pce', 'no-intro-pce']
    };

    let q = `mediatype:(software)`;
    
    if (query) {
      // Escape special characters for Archive.org
      const escapedQuery = query.replace(/[():]/g, '\\$&');
      q += ` AND title:(${escapedQuery})`;
    }

    // If system is provided, filter by specific subject or collection subset
    if (system && system !== 'All') {
      const subjects = systemSubjects[system] || [system];
      const collections = systemCollections[system] || [];
      
      let systemFilter = `(${subjects.map(s => `subject:("${s}")`).join(' OR ')})`;
      if (collections.length > 0) {
        systemFilter = `(${systemFilter} OR ${collections.map(c => `collection:("${c}")`).join(' OR ')})`;
      }
      
      q += ` AND ${systemFilter}`;
    } else {
       // If no system specified, we can optionally add a general software library filter
       // but mediatype:software is usually enough.
    }

    const sort = 'downloads+desc';
    const scrapeCount = Math.max(100, rows);
    const flParams = ['identifier', 'title', 'description', 'creator', 'date', 'subject', 'collection']
      .map(f => `fl[]=${f}`).join('&');

    // Primary and Fallback Queries
    const queries = [q];
    
    if (query && system && system !== 'All') {
      // Fallback 1: Just title and system (less restrictive subject)
      queries.push(`mediatype:(software) AND title:(${query.replace(/[():]/g, '\\$&')}) AND subject:(${system})`);
      // Fallback 2: Just title and software mediatype
      queries.push(`mediatype:(software) AND title:(${query.replace(/[():]/g, '\\$&')})`);
    }

    let searchData: any = null;
    let lastError: string = "";
    const startTime = Date.now();
    const globalTimeout = 180000; // 3 minutes total for all attempts

    // Attempt fetch with query fallback, proxy rotation and endpoint fallback
    for (const currentQ of queries) {
      if (searchData || (Date.now() - startTime > globalTimeout)) break;

      const endpoints = [];
      
      if (page === 1) {
        endpoints.push(`https://archive.org/services/search/v1/scrape?q=${encodeURIComponent(currentQ)}&fields=identifier,title,description,creator,date,subject,collection&count=${scrapeCount}`);
      }
      
      endpoints.push(`https://archive.org/advancedsearch.php?q=${encodeURIComponent(currentQ)}&${flParams}&sort[]=${sort}&rows=${rows}&page=${page}&output=json`);

      for (const endpoint of endpoints) {
        if (searchData || (Date.now() - startTime > globalTimeout)) break;
        
        let endpointSuccess = false;

        for (const proxy of (proxies as any[])) {
          if (Date.now() - startTime > globalTimeout) break;
          
          try {
            let fetchUrl = endpoint;
            if (proxy.name === 'CorsProxy') {
              fetchUrl = `${proxy.url}${endpoint}`;
            } else if (proxy.url) {
              fetchUrl = `${proxy.url}${encodeURIComponent(endpoint)}`;
            }
            console.log(`[Archive.org Search] Attempting via ${proxy.name} (${currentQ.substring(0, 20)}...): ${proxy.name === 'LocalTunnel' ? 'tunneling' : fetchUrl}`);
            
            const controller = new AbortController();
            const timeout = proxy.timeout || 25000;
            const timeoutId = setTimeout(() => controller.abort(), timeout); 
            
            // Add small jitter to avoid slamming the server
            await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 500));
            
            const response = await fetch(fetchUrl, { 
              signal: controller.signal,
              headers: {
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
              }
            });
            clearTimeout(timeoutId);

            if (!response.ok) {
              let errText = await response.text().catch(() => "No error body");
              
              // Clean up AllOrigins/Proxy internal errors to be more readable
              if (errText.includes('"error":"Error: internal error"')) {
                errText = "Proxy Internal Error (Target might be unreachable)";
              }

              // If it's a 503, 429 or 408, move to next proxy
              if (response.status === 503 || response.status === 429 || response.status === 408) {
                console.warn(`[Archive.org Search] ${proxy.name} returned ${response.status}. Moving to next proxy...`);
                continue;
              }

              // If it's a paging error, stop this query
              if (errText.includes('DEEP_PAGING') || errText.includes('paging limit')) {
                throw new Error(`Archive.org API Error: [DEEP_PAGING] Limit reached at page ${page}`);
              }
              throw new Error(`Status ${response.status}: ${errText.substring(0, 50)}`);
            }
            
            const text = await response.text();
            if (!text || text.trim().startsWith('<!DOCTYPE')) {
              throw new Error('Received HTML instead of JSON');
            }

            try {
              const data = JSON.parse(text);
              
              if (data.error) {
                throw new Error(`Archive.org API Error: ${data.error}`);
              }

              if (data.response && Array.isArray(data.response.docs)) {
                searchData = data;
                endpointSuccess = true;
                console.log(`[Archive.org Search] Success via ${proxy.name} with ${searchData.response.docs.length} results.`);
                break; // Break proxy loop
              } else if (data.items && Array.isArray(data.items)) {
                searchData = { response: { docs: data.items } };
                endpointSuccess = true;
                console.log(`[Archive.org Search] Success via ${proxy.name} with ${searchData.response.docs.length} results.`);
                break; // Break proxy loop
              } else {
                 throw new Error('Invalid data format: missing docs or items array');
              }
            } catch (e) {
              if (e instanceof Error && (e.message.includes('Archive.org API Error') || e.message.includes('Received HTML'))) {
                throw e;
              }
              throw new Error('Invalid JSON response or format');
            }
          } catch (e) {
            const err = e instanceof Error ? e.message : String(e);
            
            // Handle aborted signal specifically
            if (err.includes('aborted') || err.includes('timeout')) {
              lastError = `Timeout after ${proxy.timeout}ms via ${proxy.name}`;
            } else {
              lastError = err;
            }
            
            console.warn(`[Archive.org Search] Proxy ${proxy.name} failed: ${lastError}`);
            
            // If it's a logical API error (like deep paging), don't try other proxies
            if (lastError.includes('DEEP_PAGING')) break;
          }
        }
        
        if (endpointSuccess) break;
      }
    }

    if (!searchData) {
      const timeTaken = Math.round((Date.now() - startTime) / 1000);
      throw new Error(`All queries, proxies and endpoints failed after ${timeTaken}s. Last error: ${lastError}`);
    }

    const docs = searchData.response.docs;
    const normalizedGames: GameObject[] = [];

    // Fast normalization without fetching metadata for each file
    for (const doc of docs) {
      try {
        const game = this.normalizeFast(doc);
        if (game && game.system !== 'Unknown') {
          normalizedGames.push(game);
        }
      } catch (err) {
        console.error(`Error normalizing ${doc.identifier}:`, err);
      }
    }

    return this.deduplicate(normalizedGames);
  }

  /**
   * Fetch real data from Archive.org (Legacy/Collection based)
   */
  public static async fetchFromArchiveOrg(collection: string = 'softwarelibrary_snes', limit: number = 50): Promise<GameObject[]> {
     // Redirect to search if possible, or keep as is for compatibility
     // For now, let's keep it but use the new normalization logic
     return this.searchArchiveOrg(collection, 'All'); // This is not quite right, but we are moving to search
  }
}

